package com.capstone.project.donar;


public interface DonarDao {
	
	public void registerDonar(DonarDTO d);
	
}
