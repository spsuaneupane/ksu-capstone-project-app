package com.capstone.project.admin.status;


public interface AdminStatusDao {
	
	public AdminStatusResponse changeStatus(AdminStatusRequest r);
	
}
