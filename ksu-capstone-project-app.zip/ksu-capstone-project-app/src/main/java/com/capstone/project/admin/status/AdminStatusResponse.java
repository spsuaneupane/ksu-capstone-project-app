package com.capstone.project.admin.status;

public class AdminStatusResponse {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
