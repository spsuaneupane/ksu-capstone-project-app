package com.capstone.project.family;

public class Child {

	public String name;
	public String image;
	public String wishname;
	public String familyid;
	
	public String getFamilyid() {
		return familyid;
	}
	public void setFamilyid(String familyid) {
		this.familyid = familyid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getWishname() {
		return wishname;
	}
	public void setWishname(String wishname) {
		this.wishname = wishname;
	}
	
	
}
