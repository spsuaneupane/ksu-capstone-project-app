package com.capstone.project.admin;


public interface AdminDao {
	
	public AdminResponse getAllFamilies();
	
}
