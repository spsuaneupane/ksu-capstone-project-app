package com.capstone.project.donation.wish;

import java.util.List;


public interface DonationWishDao {
	
	public List<DonationWish> geallWish(String familyId);
	
}
