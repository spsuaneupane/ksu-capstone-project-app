package com.capstone.project.family;


public interface FamilyDao {
	
	public void registerFamily(FamilyDTOUI d);
	
}
