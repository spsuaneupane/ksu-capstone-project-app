package com.capstone.project.donation.wish;

import java.util.List;

public class DonationWishResponse {

	
	private List<DonationWish> wishes;

	public List<DonationWish> getWishes() {
		return wishes;
	}

	public void setWishes(List<DonationWish> wishes) {
		this.wishes = wishes;
	}

}
