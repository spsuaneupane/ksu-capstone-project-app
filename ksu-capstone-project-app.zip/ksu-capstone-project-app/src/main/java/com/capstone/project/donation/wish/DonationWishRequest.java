package com.capstone.project.donation.wish;

public class DonationWishRequest {

	
	private String familyId;

	
	public String getFamilyId() {
		return familyId;
	}

	public void setFamilyId(String familyId) {
		this.familyId = familyId;
	}
	
}
