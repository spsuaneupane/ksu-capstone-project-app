package com.capstone.project.admin;

import java.util.List;


public class AdminResponse {
	
	private List<AdminDTO> admindtos;
	
	
	public List<AdminDTO> getAdmindtos() {
		return admindtos;
	}

	public void setAdmindtos(List<AdminDTO> admindtos) {
		this.admindtos = admindtos;
	}
	
	
}
