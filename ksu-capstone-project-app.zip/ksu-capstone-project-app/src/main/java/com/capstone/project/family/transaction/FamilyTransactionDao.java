package com.capstone.project.family.transaction;



public interface FamilyTransactionDao {
	
	public FamilyTransactionResponse finalSubmitDonation(String familyId);
	
}
