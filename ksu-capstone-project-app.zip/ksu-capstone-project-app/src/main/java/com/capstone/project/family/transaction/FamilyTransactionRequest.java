package com.capstone.project.family.transaction;


public class FamilyTransactionRequest {

	private String familyId;

	public String getFamilyId() {
		return familyId;
	}

	public void setFamilyId(String familyId) {
		this.familyId = familyId;
	}	
}
