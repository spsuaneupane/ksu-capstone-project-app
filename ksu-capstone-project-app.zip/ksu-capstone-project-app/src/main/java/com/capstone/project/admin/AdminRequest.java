package com.capstone.project.admin;




public class AdminRequest {
	
	private String family;

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

}
