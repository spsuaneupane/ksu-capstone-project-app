package com.capstone.project.donar.transaction;



public interface DonarTransactionDao {
	
	public DonarTransactionResponse finalSubmitTransactionRequest(String familyId);
	
}
