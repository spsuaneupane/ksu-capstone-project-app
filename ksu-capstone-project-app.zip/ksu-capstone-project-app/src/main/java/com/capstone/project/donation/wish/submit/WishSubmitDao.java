package com.capstone.project.donation.wish.submit;



public interface WishSubmitDao {
	
	public WishSubmitResponse finalSubmitDonation(WishSubmitRequest r);
	
}
