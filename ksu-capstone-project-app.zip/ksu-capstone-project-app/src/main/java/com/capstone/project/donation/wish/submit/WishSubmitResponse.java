package com.capstone.project.donation.wish.submit;

public class WishSubmitResponse {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
