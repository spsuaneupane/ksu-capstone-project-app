package com.capstone.project.user;



public class ServiceStatus {

	

	private String messageStatus;

	public String getMessageStatus() {
		return messageStatus;
	}

	public void setMessageStatus(String messageStatus) {
		this.messageStatus = messageStatus;
	}
	

}
